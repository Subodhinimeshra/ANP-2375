package com.anudip.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SbjpaExApplication {

	public static void main(String[] args) {
		SpringApplication.run(SbjpaExApplication.class, args);
	}

}
