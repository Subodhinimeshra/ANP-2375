package com.anudip.jpa.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="PassengerInfo")

//first entity
public class Passenger {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(length = 30, nullable = false)
	@NotBlank(message = "Enter your name")
	private String pName;
	
	@Column(length = 30, nullable = false)
	@NotBlank(message = "Enter your surname")
	private String pSurname;
	
	@Column(length = 30, nullable = false, unique = true)
	@Email(message = "Enter proper email id")
	@NotBlank(message = "Enter your email id")
	private String pEmail;
	
	@Column(length = 30, nullable = false, unique = true)
	@NotNull(message="Enter your phone number")
	private long phone;

}
