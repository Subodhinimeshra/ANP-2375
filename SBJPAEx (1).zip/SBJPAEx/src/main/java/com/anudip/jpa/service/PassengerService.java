package com.anudip.jpa.service;

import java.util.List;

import com.anudip.jpa.entity.Passenger;

//abstract method for performing CRUD on entity Passenger
public interface PassengerService {
	
	//method for saving passenger details
	Passenger savePassenger(Passenger pass);
	
	// method for fetching passenger detail based on pid
	Passenger getByIdPassenger(long pid);
	
	//method for fetching all passenger details
	List<Passenger> getAllPassengers();
	
	//method for updating passenger details based on pid
	Passenger updateByIdPassenger(Passenger pass, long pid);
	
	//method for removing passenger detail based on pid
	void deleteByIdPassenger(long pid);
}
