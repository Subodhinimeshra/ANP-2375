package com.anudip.jpa.exception;

//custom exception to handle Passenger entity
public class PassengerNotFoundException extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public PassengerNotFoundException(String message) {
		super(message);
		
	}
	
	

}
