package com.anudip.jpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbjpaExApplicationTests {

	@Test
	void contextLoads() {
	}

}
