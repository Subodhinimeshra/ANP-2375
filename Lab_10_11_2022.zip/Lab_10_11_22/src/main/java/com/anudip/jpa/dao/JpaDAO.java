package com.anudip.jpa.dao;

public interface JpaDAO {
	
	public void emp();
	
	public void proj();

}